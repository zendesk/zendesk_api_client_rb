The basic Zendesk App template
==========

This is just a empty template for creating apps

